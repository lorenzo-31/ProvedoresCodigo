<?php
include("conexion.php");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit();
}

$id = filter_input(INPUT_POST, "id", FILTER_VALIDATE_INT);
if (!$id) {
    die("ID de proveedor no válido.");
}

$nombre_cliente = trim($_POST["nombre_c"] ?? "");
$apellido_cliente = trim($_POST["apellido_c"] ?? "");
$nombre_proveedor = trim($_POST["nombre_p"] ?? "");
$producto = trim($_POST["producto"] ?? "");
$cantidad = trim($_POST["cantidad"] ?? "");
$telefono_cliente = trim($_POST["telefono_c"] ?? "");
$telefono_proveedor = trim($_POST["telefono_p"] ?? "");

$camposTextoValidos = strlen($nombre_cliente) >= 2 && strlen($apellido_cliente) >= 2 &&
    strlen($nombre_proveedor) >= 2 && strlen($producto) >= 2;
$cantidadValida = preg_match('/^[0-9]+$/', $cantidad) && (int)$cantidad >= 1;
$telefonosValidos = preg_match('/^[0-9]{10}$/', $telefono_cliente) &&
    preg_match('/^[0-9]{10}$/', $telefono_proveedor);

if (!$camposTextoValidos || !$cantidadValida || !$telefonosValidos) {
    header("Location: index.php?error=datos");
    exit();
}

$cantidad = (int)$cantidad;
$sql = "UPDATE proveedores SET nombre_c = ?, apellido_c = ?, nombre_p = ?, producto = ?, cantidad = ?, telefono_c = ?, telefono_p = ? WHERE id = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("ssssissi", $nombre_cliente, $apellido_cliente, $nombre_proveedor, $producto, $cantidad, $telefono_cliente, $telefono_proveedor, $id);

if ($stmt->execute()) {
    header("Location: index.php?estado=actualizado");
    exit();
}

error_log("Error al actualizar proveedor: " . $stmt->error);
header("Location: index.php?error=guardar");
exit();
?>
