<?php
$servidor = "localhost";
$usuario = "root";
$password = "";
$base_datos = "proveedores";

$conexion = new mysqli($servidor, $usuario, $password, $base_datos);

if ($conexion->connect_error) {
    die("Error de conexión: " . htmlspecialchars($conexion->connect_error, ENT_QUOTES, 'UTF-8'));
}

$conexion->set_charset("utf8mb4");
?>
