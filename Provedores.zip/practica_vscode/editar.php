<?php
include("conexion.php");

$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);
if (!$id) {
    die("ID de proveedor no válido.");
}

$stmt = $conexion->prepare("SELECT * FROM proveedores WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$resultado = $stmt->get_result();
$proveedor = $resultado->fetch_assoc();

if (!$proveedor) {
    die("No se encontró el proveedor solicitado.");
}
function e($valor) {
    return htmlspecialchars((string)($valor ?? ''), ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Editar Proveedor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .btn { transition: transform .18s ease, filter .18s ease, box-shadow .18s ease; }
        .btn.boton-resaltado { transform: translateY(-2px) scale(1.04); filter: brightness(1.12); box-shadow: 0 4px 10px rgba(0,0,0,.2); }
    </style>
</head>
<body class="bg-light">
<div class="container mt-5 mb-5">
    <div class="card shadow">
        <div class="card-header bg-warning"><h3 class="mb-0">Editar Proveedor</h3></div>
        <div class="card-body">
            <form action="actualizar.php" method="POST" id="registroForm" novalidate>
                <input type="hidden" name="id" value="<?= (int)$proveedor['id'] ?>">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="nombre_c" class="form-label">Nombre del Cliente</label>
                        <input type="text" id="nombre_c" name="nombre_c" class="form-control" minlength="2" maxlength="100" value="<?= e($proveedor['nombre_c']) ?>" required>
                        <div class="mensaje-error text-danger small mt-1" aria-live="polite"></div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="apellido_c" class="form-label">Apellido del Cliente</label>
                        <input type="text" id="apellido_c" name="apellido_c" class="form-control" minlength="2" maxlength="100" value="<?= e($proveedor['apellido_c']) ?>" required>
                        <div class="mensaje-error text-danger small mt-1" aria-live="polite"></div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="telefono_c" class="form-label">Teléfono del Cliente</label>
                        <input type="tel" id="telefono_c" name="telefono_c" class="form-control" inputmode="numeric" pattern="[0-9]{10}" minlength="10" maxlength="10" value="<?= e($proveedor['telefono_c']) ?>" required>
                        <div class="mensaje-error text-danger small mt-1" aria-live="polite"></div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="nombre_p" class="form-label">Nombre del Proveedor</label>
                        <input type="text" id="nombre_p" name="nombre_p" class="form-control" minlength="2" maxlength="100" value="<?= e($proveedor['nombre_p']) ?>" required>
                        <div class="mensaje-error text-danger small mt-1" aria-live="polite"></div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="producto" class="form-label">Producto</label>
                        <input type="text" id="producto" name="producto" class="form-control" minlength="2" maxlength="150" value="<?= e($proveedor['producto']) ?>" required>
                        <div class="mensaje-error text-danger small mt-1" aria-live="polite"></div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="cantidad" class="form-label">Cantidad</label>
                        <input type="number" id="cantidad" name="cantidad" class="form-control" min="1" step="1" value="<?= e($proveedor['cantidad']) ?>" required>
                        <div class="mensaje-error text-danger small mt-1" aria-live="polite"></div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="telefono_p" class="form-label">Teléfono del Proveedor</label>
                        <input type="tel" id="telefono_p" name="telefono_p" class="form-control" inputmode="numeric" pattern="[0-9]{10}" minlength="10" maxlength="10" value="<?= e($proveedor['telefono_p']) ?>" required>
                        <div class="mensaje-error text-danger small mt-1" aria-live="polite"></div>
                    </div>
                </div>
                <button type="submit" class="btn btn-success">Actualizar</button>
                <a href="index.php" class="btn btn-secondary">Cancelar</a>
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
const formulario = document.getElementById('registroForm');
const campos = formulario.querySelectorAll('input[required]');

function validarCampo(campo) {
    let mensaje = '';
    const valor = campo.value.trim();
    if (valor === '') mensaje = 'Este campo es obligatorio.';
    else if (campo.name === 'cantidad') {
        if (!/^\d+$/.test(valor) || Number(valor) < 1) mensaje = 'Ingresa una cantidad entera mayor que cero.';
    } else if (campo.name === 'telefono_c' || campo.name === 'telefono_p') {
        if (!/^\d{10}$/.test(valor)) mensaje = 'Escribe exactamente 10 dígitos numéricos.';
    } else if (valor.length < 2) mensaje = 'Escribe al menos 2 caracteres.';

    campo.setCustomValidity(mensaje);
    campo.classList.toggle('is-invalid', mensaje !== '');
    campo.classList.toggle('is-valid', mensaje === '');
    const aviso = campo.parentElement.querySelector('.mensaje-error');
    if (aviso) aviso.textContent = mensaje;
    return mensaje === '';
}

campos.forEach(campo => {
    campo.addEventListener('input', () => validarCampo(campo));
    campo.addEventListener('blur', () => validarCampo(campo));
});

formulario.addEventListener('submit', evento => {
    let valido = true;
    campos.forEach(campo => { if (!validarCampo(campo)) valido = false; });
    if (!valido) {
        evento.preventDefault();
        const primerInvalido = formulario.querySelector('.is-invalid');
        if (primerInvalido) primerInvalido.focus();
        Swal.fire({icon:'error', title:'¡Revisa el formulario!', text:'Corrige los campos marcados antes de actualizar.', confirmButtonColor:'#dc3545'});
    }
});

document.querySelectorAll('.btn').forEach(boton => {
    boton.addEventListener('mouseenter', evento => evento.currentTarget.classList.add('boton-resaltado'));
    boton.addEventListener('mouseleave', evento => evento.currentTarget.classList.remove('boton-resaltado'));
});
</script>
</body>
</html>
