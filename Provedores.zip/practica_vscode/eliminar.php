<?php
include("conexion.php");

$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);
if (!$id) {
    die("ID de proveedor no válido.");
}

$stmt = $conexion->prepare("DELETE FROM proveedores WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: index.php?estado=eliminado");
    exit();
}

echo "Error al eliminar el registro.";
?>
