<?php
include("conexion.php");

$sql = "SELECT * FROM proveedores ORDER BY id DESC";
$resultado = $conexion->query($sql);

function e($valor) {
    return htmlspecialchars((string)($valor ?? ''), ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CRUD de Proveedores</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .btn { transition: transform .2s ease, box-shadow .2s ease, filter .2s ease; }
        .btn.boton-resaltado { transform: translateY(-3px) scale(1.04); filter: brightness(1.1); box-shadow: 0 5px 12px rgba(0,0,0,.2); }
        .mensaje-error { display:block; }
    </style>
</head>
<body class="bg-light">
<div class="container mt-5 mb-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h2 class="text-center mb-0">Sistema de Proveedores</h2>
        </div>
        <div class="card-body">
            <h4 class="mb-4">Registrar proveedor</h4>

            <form action="guardar.php" method="POST" id="registroForm" novalidate>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="nombre_c" class="form-label">Nombre del Cliente</label>
                        <input type="text" id="nombre_c" name="nombre_c" class="form-control" minlength="2" maxlength="100" required>
                        <div class="mensaje-error text-danger small mt-1" aria-live="polite"></div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="apellido_c" class="form-label">Apellido del Cliente</label>
                        <input type="text" id="apellido_c" name="apellido_c" class="form-control" minlength="2" maxlength="100" required>
                        <div class="mensaje-error text-danger small mt-1" aria-live="polite"></div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="nombre_p" class="form-label">Nombre del Proveedor</label>
                        <input type="text" id="nombre_p" name="nombre_p" class="form-control" minlength="2" maxlength="100" required>
                        <div class="mensaje-error text-danger small mt-1" aria-live="polite"></div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="producto" class="form-label">Producto</label>
                        <input type="text" id="producto" name="producto" class="form-control" minlength="2" maxlength="150" required>
                        <div class="mensaje-error text-danger small mt-1" aria-live="polite"></div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="cantidad" class="form-label">Cantidad</label>
                        <input type="number" id="cantidad" name="cantidad" class="form-control" min="1" step="1" required>
                        <div class="mensaje-error text-danger small mt-1" aria-live="polite"></div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="telefono_c" class="form-label">Teléfono del Cliente</label>
                        <input type="tel" id="telefono_c" name="telefono_c" class="form-control" inputmode="numeric" pattern="[0-9]{10}" minlength="10" maxlength="10" placeholder="10 dígitos" autocomplete="tel" required>
                        <div class="mensaje-error text-danger small mt-1" aria-live="polite"></div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="telefono_p" class="form-label">Teléfono del Proveedor</label>
                        <input type="tel" id="telefono_p" name="telefono_p" class="form-control" inputmode="numeric" pattern="[0-9]{10}" minlength="10" maxlength="10" placeholder="10 dígitos" required>
                        <div class="mensaje-error text-danger small mt-1" aria-live="polite"></div>
                    </div>
                </div>
                <button type="submit" class="btn btn-success">Registrar Proveedor</button>
            </form>
        </div>
    </div>

    <div class="card shadow mt-4">
        <div class="card-header"><h4 class="mb-0">Lista de Proveedores</h4></div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Nombre del Cliente</th>
                            <th>Teléfono del Cliente</th>
                            <th>Nombre del Proveedor</th>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Teléfono del Proveedor</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($proveedor = $resultado->fetch_assoc()) { ?>
                        <tr>
                            <td><?= e($proveedor['id']) ?></td>
                            <td><?= e(($proveedor['nombre_c'] ?? '') . ' ' . ($proveedor['apellido_c'] ?? '')) ?></td>
                            <td><?= e($proveedor['telefono_c']) ?></td>
                            <td><?= e($proveedor['nombre_p']) ?></td>
                            <td><?= e($proveedor['producto']) ?></td>
                            <td><?= e($proveedor['cantidad']) ?></td>
                            <td><?= e($proveedor['telefono_p']) ?></td>
                            <td class="text-nowrap">
                                <a href="editar.php?id=<?= (int)$proveedor['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                                <a href="eliminar.php?id=<?= (int)$proveedor['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Deseas eliminar este proveedor?')">Eliminar</a>
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
const parametros = new URLSearchParams(window.location.search);
const estado = parametros.get('estado');
const error = parametros.get('error');

if (estado === 'registrado') {
    Swal.fire({icon:'success', title:'¡Proveedor registrado exitosamente!', text:'El proveedor se agregó a la lista.', confirmButtonColor:'#198754'});
} else if (estado === 'actualizado') {
    Swal.fire({icon:'success', title:'¡Proveedor actualizado!', text:'Los datos se guardaron correctamente.', confirmButtonColor:'#198754'});
} else if (estado === 'eliminado') {
    Swal.fire({icon:'success', title:'¡Proveedor eliminado!', text:'El registro se eliminó correctamente.', confirmButtonColor:'#198754'});
} else if (error) {
    const mensajes = {
        datos: 'Revisa los campos. Los teléfonos deben tener exactamente 10 dígitos y la cantidad debe ser un entero mayor que cero.',
        guardar: 'No fue posible guardar el registro. Verifica la estructura de la base de datos.'
    };
    Swal.fire({icon:'error', title:'No se pudo completar la operación', text:mensajes[error] || 'Ocurrió un error.', confirmButtonColor:'#dc3545'});
}
if (estado || error) window.history.replaceState({}, document.title, window.location.pathname);

const formulario = document.getElementById('registroForm');
const campos = formulario.querySelectorAll('input[required]');

function validarCampo(campo) {
    let mensaje = '';
    const valor = campo.value.trim();

    if (valor === '') {
        mensaje = 'Este campo es obligatorio.';
    } else if (campo.name === 'cantidad') {
        if (!/^\d+$/.test(valor) || Number(valor) < 1) mensaje = 'Ingresa una cantidad entera mayor que cero.';
    } else if (campo.name === 'telefono_c' || campo.name === 'telefono_p') {
        if (!/^\d{10}$/.test(valor)) mensaje = 'Escribe exactamente 10 dígitos numéricos.';
    } else if (valor.length < 2) {
        mensaje = 'Escribe al menos 2 caracteres.';
    }

    campo.setCustomValidity(mensaje);
    campo.classList.toggle('is-invalid', mensaje !== '');
    campo.classList.toggle('is-valid', mensaje === '');
    const contenedor = campo.parentElement;
    let aviso = contenedor.querySelector('.mensaje-error');
    if (!aviso) {
        aviso = document.createElement('div');
        aviso.className = 'mensaje-error text-danger small mt-1';
        aviso.setAttribute('aria-live', 'polite');
        contenedor.appendChild(aviso);
    }
    aviso.textContent = mensaje;
    return mensaje === '';
}

campos.forEach(campo => {
    campo.addEventListener('input', () => validarCampo(campo));
    campo.addEventListener('blur', () => validarCampo(campo));
});

formulario.addEventListener('submit', evento => {
    let valido = true;
    campos.forEach(campo => { if (!validarCampo(campo)) valido = false; });
    if (!valido) {
        evento.preventDefault();
        const primerInvalido = formulario.querySelector('.is-invalid');
        if (primerInvalido) primerInvalido.focus();
        Swal.fire({icon:'error', title:'¡Revisa el formulario!', text:'Corrige los campos marcados antes de registrar.', confirmButtonColor:'#dc3545'});
    }
});

document.querySelectorAll('.btn').forEach(boton => {
    boton.addEventListener('mouseenter', evento => evento.currentTarget.classList.add('boton-resaltado'));
    boton.addEventListener('mouseleave', evento => evento.currentTarget.classList.remove('boton-resaltado'));
});
</script>
</body>
</html>
